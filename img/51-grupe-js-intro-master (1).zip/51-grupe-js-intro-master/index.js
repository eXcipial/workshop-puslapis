// vienos eilutes komentara

/*
keliu
eiluciu
komentaras
*/

console.clear();

console.log(123);
console.log(4, 5, 6, 7, 8, 9);

// console.clear();

/*
- kintamieji (duomenu tipai):
    + iniciavimo būdai
    + number
    + string (tekstas)
    + boolean (true/false)
    + array (sąrašas)
    + object (kompleksiškas duomuo/struktūra)
    + null
    + undefined
- salygos/palyginimo (if):
    + boolean logika
    + if
    - switch
    + ternary
- ciklai (for):
    + for
    + for-of
    - for-in
    + while
    - do-while (patys, jei norit)
    - cikliski metodai:
        - map
        - filter
        - sort
        - reduce
        - foreach
        - N+1...
+ import-export
- function:
    + "iprastos" deklaruotinos
    - anonimines (priskirtos kintamajam)
    - rodyklines (arrow)
- methods:
    - number
    - string
    - array
    - object
- class (oop):
    - class
    - inheritence
    - private values
    - static method
- event listeners:
    - keyboard click
    - mouse click (left/main)
    - mouse click (right/context)
    - scroll
*/
